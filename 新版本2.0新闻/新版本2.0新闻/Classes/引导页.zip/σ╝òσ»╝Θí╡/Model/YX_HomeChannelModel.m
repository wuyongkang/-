//
//  YX_HomeChannelModel.m
//  新版本2.0新闻
//
//  Created by Eric.Wu on 17/2/22.
//  Copyright © 2017年 广州伊秀科技有限公司. All rights reserved.
//

#import "YX_HomeChannelModel.h"

@implementation YX_HomeChannelModel

@end
